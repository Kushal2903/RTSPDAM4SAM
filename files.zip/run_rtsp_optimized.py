"""
Optimized DAM4SAM RTSP streaming script for Jetson Orin AGX 64GB.

Changes vs. the original script, and why:

1. Removed the periodic `torch.cuda.empty_cache()` call, and patched
   dam4sam_tracker.py to remove the one INSIDE track() (called every frame).
   empty_cache() doesn't free memory you're using - it hands cached blocks
   back to the CUDA driver, so the next allocation has to go through a slow
   cudaMalloc round-trip. Doing that every frame, forever, is the single
   biggest performance killer in the original setup. Never call it in a
   steady-state inference loop.

2. INFERENCE_INTERVAL = 1 (process every frame, as requested). Understand
   the tradeoff: this maximizes GPU usage, not minimizes it. If you need
   <60% GPU while doing every frame, the real fix is making each frame
   cheaper (TensorRT), not skipping code-level "optimizations" that
   actually cost you (like the two removed above).

3. Frames are passed to the tracker as raw numpy arrays (no PIL round trip).
   Requires the small dam4sam_tracker.py patch (see chat) that lets
   _prepare_image / initialize accept ndarrays directly.

4. cudnn.benchmark = True: your input shape is fixed (1024x1024, every
   frame), so let cuDNN autotune kernels once and reuse them, instead of
   re-picking algorithms.

5. Instrumentation: reports RTSP arrival FPS separately from
   processing FPS, plus a rolling average inference time in ms, so you can
   see whether you are compute-bound or camera-bound. Run `tegrastats` in a
   separate terminal alongside this to see real GPU utilization/clocks -
   don't trust only in-app timers for that.

Run `sudo nvpmodel -m 0 && sudo jetson_clocks` before testing. If you
haven't done this, your GPU may be running at reduced clocks, which alone
can make a tiny model look as expensive as a much bigger one.
"""

import subprocess
import threading
import time
import collections

import cv2
import numpy as np
import torch

from dam4sam_tracker import DAM4SAMTracker
from utils.visualization_utils import overlay_mask
from utils.box_selector import BoxSelector

WIDTH = 1024
HEIGHT = 1024
MODEL = "sam21pp-T"

# Process every frame that arrives. This is a request for maximum GPU
# usage, not minimum - see note in module docstring.
INFERENCE_INTERVAL = 1

RTSP_URL = r"rtsp://172.72.8.11:554/live/0/0"

# ---- perf flags: fixed shape every frame, so let cuDNN autotune once ----
torch.backends.cudnn.benchmark = True
torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True

latest_frame = None
frame_id = 0
frame_lock = threading.Lock()
running = True


def start_ffmpeg(rtsp_url):
    frame_size = WIDTH * HEIGHT * 3
    command = [
        "ffmpeg", "-rtsp_transport", "tcp",
        "-fflags", "nobuffer+discardcorrupt+fastseek",
        "-flags", "low_delay", "-avioflags", "direct",
        "-analyzeduration", "0", "-threads", "2",
        "-i", rtsp_url, "-tune", "zerolatency",
        "-an", "-sn", "-vf", f"scale={WIDTH}:{HEIGHT}",
        "-pix_fmt", "bgr24", "-f", "rawvideo",
        "-loglevel", "error", "-"
    ]
    print("\nStarting FFmpeg...")
    print("RTSP:", rtsp_url)
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, bufsize=1024 * 1024)
    return process, frame_size


def read_rtsp(process, frame_size):
    global latest_frame, frame_id, running
    print("RTSP reader started.")
    arrival_times = collections.deque(maxlen=60)
    while running:
        try:
            raw = process.stdout.read(frame_size)
            if len(raw) != frame_size:
                if not running:
                    break
                continue
            frame = np.frombuffer(raw, dtype=np.uint8).reshape(HEIGHT, WIDTH, 3)
            now = time.perf_counter()
            arrival_times.append(now)
            with frame_lock:
                latest_frame = frame
                frame_id += 1
                if frame_id % 60 == 0 and len(arrival_times) > 1:
                    span = arrival_times[-1] - arrival_times[0]
                    if span > 0:
                        arrival_fps = (len(arrival_times) - 1) / span
                        print(f"[RTSP source] arrival rate: {arrival_fps:.1f} fps")
        except Exception as e:
            print("RTSP error:", e)
            break
    print("RTSP reader stopped.")


def get_latest_frame_with_id():
    with frame_lock:
        if latest_frame is None:
            return None, 0
        return latest_frame.copy(), frame_id


def main():
    global running
    if not torch.cuda.is_available():
        print("ERROR: CUDA is not available.")
        return

    print("GPU:      ", torch.cuda.get_device_name(0))
    print("Model:    ", MODEL)
    print("Res:      ", f"{WIDTH}x{HEIGHT}")
    print("Interval: ", f"every {INFERENCE_INTERVAL} frame(s)")
    print("\nReminder: run `sudo nvpmodel -m 0 && sudo jetson_clocks` before")
    print("benchmarking, and watch `tegrastats` in another terminal for real")
    print("GPU utilization/clocks - don't trust only the on-screen timer.\n")

    process, frame_size = start_ffmpeg(RTSP_URL)

    reader = threading.Thread(target=read_rtsp, args=(process, frame_size), daemon=True)
    reader.start()

    print("Waiting for RTSP stream...")
    while running:
        frame, _ = get_latest_frame_with_id()
        if frame is not None:
            break
        time.sleep(0.005)

    print("RTSP connected.")
    print("Loading DAM4SAM...")
    tracker = DAM4SAMTracker(MODEL)
    print("DAM4SAM loaded.")

    window_name = "DAM4SAM RTSP (Optimized)"
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)

    tracking_initialized = False
    box_selector = BoxSelector()

    fps_counter = 0
    display_fps = 0.0
    fps_timer = time.perf_counter()
    inference_times_ms = collections.deque(maxlen=60)

    last_processed_id = -1
    frame_loop_count = 0
    pred_mask = None

    print("\n[STREAMING MODE ACTIVE]")
    print("Press SPACE to Select Object & Start Tracking")
    print("Press ESC to Exit\n")

    while running:
        frame, current_id = get_latest_frame_with_id()
        if frame is None:
            time.sleep(0.001)
            continue

        if not tracking_initialized:
            display = frame.copy()
            cv2.putText(display, "LIVE STREAMING - Press SPACE to select object", (20, 35),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 165, 255), 2)

            cv2.imshow(window_name, display)
            key = cv2.waitKey(1) & 0xFF

            if key == 27:
                break
            elif key == 32:
                print("\nStream paused for object selection...")
                init_box = box_selector.select_box(frame)

                if init_box:
                    print("Initializing tracker with bounding box...")
                    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                    with torch.inference_mode():
                        with torch.autocast(device_type="cuda", dtype=torch.float16):
                            # numpy array passed directly - no PIL conversion
                            tracker.initialize(rgb_frame, None, bbox=init_box)

                    print("Tracking initialized successfully!")
                    tracking_initialized = True

                    fps_timer = time.perf_counter()
                    fps_counter = 0
                    frame_loop_count = 0
                    pred_mask = None
                    last_processed_id = current_id
                    inference_times_ms.clear()
                else:
                    print("Selection cancelled. Resuming stream preview...")

        else:
            if current_id == last_processed_id:
                time.sleep(0.001)
                continue

            last_processed_id = current_id
            frame_loop_count += 1

            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            if frame_loop_count % INFERENCE_INTERVAL == 0 or pred_mask is None:
                inf_start = time.perf_counter()
                with torch.inference_mode():
                    with torch.autocast(device_type="cuda", dtype=torch.float16):
                        # numpy array passed directly - no PIL conversion
                        outputs = tracker.track(rgb_frame)
                inference_ms = (time.perf_counter() - inf_start) * 1000
                inference_times_ms.append(inference_ms)
                pred_mask = outputs["pred_mask"]
                inferred_this_frame = True
            else:
                inferred_this_frame = False

            display = rgb_frame.copy()
            if pred_mask is not None:
                overlay_mask(display, pred_mask, (255, 255, 0), line_width=1, alpha=0.55)

            fps_counter += 1
            elapsed = (time.perf_counter() - fps_timer)
            if elapsed >= 1.0:
                display_fps = fps_counter / elapsed
                fps_counter = 0
                fps_timer = time.perf_counter()

            avg_inf_ms = sum(inference_times_ms) / len(inference_times_ms) if inference_times_ms else 0.0
            status_text = f"Inference: {avg_inf_ms:.1f} ms (avg/60)" if inference_times_ms else "Inference: --"
            cv2.putText(display, f"Processing FPS: {display_fps:.1f}", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.putText(display, status_text, (20, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.putText(display, f"Model: {MODEL} FP16", (20, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            cv2.putText(display, "SPACE: re-select | ESC: exit", (20, HEIGHT - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            display_bgr = cv2.cvtColor(display, cv2.COLOR_RGB2BGR)
            cv2.imshow(window_name, display_bgr)

            key = cv2.waitKey(1) & 0xFF
            if key == 27:
                break
            elif key == 32:
                tracking_initialized = False
                print("\nResetting tracking system...")

            # No manual empty_cache() here - see module docstring. If you
            # ever suspect a real leak, diagnose with
            # torch.cuda.memory_summary(), don't paper over it with
            # empty_cache() in the hot loop.

    print("\nStopping stream...")
    running = False
    try:
        process.kill()
        process.wait(timeout=2)
    except Exception:
        pass
    cv2.destroyAllWindows()
    print("Done.")


if __name__ == "__main__":
    main()
